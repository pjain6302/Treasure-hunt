class System{

    constructor(){}

    // Add code to authenticate the given code and the access codes.

    

}