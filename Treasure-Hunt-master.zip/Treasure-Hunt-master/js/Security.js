class Security {

    constructor(){

        // Add code to create the input and button elements


    }

    display(){

        // Add code to make the buttons function as expected


    }
}